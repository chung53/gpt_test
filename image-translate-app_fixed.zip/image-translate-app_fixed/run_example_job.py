import json
import os
from services.worker.worker import run_job


if __name__ == '__main__':
    inp = os.path.abspath('examples/input/sample.json')
    out = run_job(inp, {'ocr': {'force_text': '示例'}, 'translation': {'style': 'literal'}})
    print(json.dumps(out, ensure_ascii=False, indent=2))
