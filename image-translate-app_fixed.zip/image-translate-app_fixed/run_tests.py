import os
import pathlib
import sys
import unittest


def main() -> None:
    # Ensure that tests are discovered relative to this file's directory.
    os.chdir(pathlib.Path(__file__).parent)
    loader = unittest.defaultTestLoader
    suite = loader.discover('tests', pattern='test*.py')
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)


if __name__ == '__main__':
    main()
