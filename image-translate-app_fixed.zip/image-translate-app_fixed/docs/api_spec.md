# API Spec (MVP)

- Backend (FastAPI placeholder): /v1/jobs（未在 MVP 内启动 HTTP，仅保留代码结构）
- Worker: `run_job(input_path, params)` 返回输出产物路径
