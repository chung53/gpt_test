# Architecture Overview

该项目按照模块化蓝图拆分为独立服务，每个服务对外暴露 Python 接口（也可升级为 RPC/REST）。
MVP 版本以标准库实现模拟逻辑，保证接口、数据契约与流水线顺序一致，可运行可测试。
