import unittest
from services.compositor.composer import compose
from services.compositor.validator import byte_for_byte_same


class TestCompositor(unittest.TestCase):
    def test_compose_and_validate(self):
        orig = {'data': [[5] * 5 for _ in range(5)]}
        inpainted = {'data': [[0] * 5 for _ in range(5)]}
        text_layer = {'data': [[7] * 5 for _ in range(5)]}
        mask = [[False] * 5 for _ in range(5)]
        for y in range(1, 4):
            for x in range(1, 4):
                mask[y][x] = True
        out = compose(orig, inpainted, text_layer, mask)
        # Non-mask values unchanged
        self.assertTrue(byte_for_byte_same(out, orig, mask))
        # Mask area set to 7
        for y in range(1, 4):
            for x in range(1, 4):
                self.assertEqual(out['data'][y][x], 7)


if __name__ == '__main__':
    unittest.main()
