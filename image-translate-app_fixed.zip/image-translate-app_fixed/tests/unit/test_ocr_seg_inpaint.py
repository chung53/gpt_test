import unittest
from services.ocr.ocr_service import run_ensemble
from services.segmentation.sam_wrapper import generate_mask
from services.segmentation.refine import refine
from services.inpainting.candidate_manager import generate_and_rank


class TestPipelineParts(unittest.TestCase):
    def setUp(self):
        self.img = {'data': [[5] * 8 for _ in range(8)]}

    def test_flow(self):
        units = run_ensemble(self.img, {'force_text': 'Hello'})
        mask = generate_mask(self.img, units[0]['bbox'])
        refined_mask, meta = refine(mask)
        cands = generate_and_rank(self.img, refined_mask)
        self.assertTrue(len(cands) >= 1)
        self.assertIn('data', cands[0])


if __name__ == '__main__':
    unittest.main()
