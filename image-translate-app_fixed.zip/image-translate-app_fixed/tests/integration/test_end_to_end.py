import os
import unittest
from services.worker.worker import run_job
from tools.utils.image_io import load_image


class TestEndToEnd(unittest.TestCase):
    def test_run_job(self):
        inp = os.path.abspath('examples/input/sample.json')
        out = run_job(inp, {'ocr': {'force_text': 'Hi'}, 'translation': {'style': 'literal'}})
        self.assertIn('final', out)
        img = load_image(out['final'])
        self.assertIn('data', img)
        # Check that a non-mask pixel retains the original value (5)
        self.assertEqual(img['data'][0][0], 5)


if __name__ == '__main__':
    unittest.main()
