# image-translate-app (MVP runnable skeleton)

这是一个可运行的最小可行版本（MVP），按你给出的模块化蓝图实现了端到端的流水线结构：
OCR → segmentation → inpainting → translation → font → render → compositor → validator。
为了保证在本环境下**可直接运行测试**，所有实现均使用 Python 标准库完成**可替代的轻量模拟**，
不依赖外部模型与图形库，但保留了**相同的模块边界、接口、文件结构**，便于后续替换为真实模型。

- 运行单元与集成测试：

  ```bash
  python run_tests.py
  ```

- 运行一个示例作业（会在 `outputs/` 下生成产物）：

  ```bash
  python scripts/run_example_job.py
  ```

- 后续落地到 A800：只需将各 services 下的轻量实现替换为真实推理（SAM/LaMa/LLM/Skia 等），
  接口保持不变；CI、Docker、k8s、监控留有占位以扩展。

---

## 快速安装（中文）

- **最小运行（无三方库）**：
  ```bash
  python -m venv .venv
  . .venv/bin/activate
  pip install -r requirements-min.txt
  python run_tests.py
  python scripts/run_example_job.py
  ```

- **启动后端（需要FastAPI）**：
  ```bash
  pip install -r requirements.txt
  uvicorn services.backend.app:app --host 0.0.0.0 --port 8000
  ```

- **Makefile 速用**：
  ```bash
  make venv install test example
  ```
