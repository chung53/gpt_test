from .lama_service import inpaint


def generate_and_rank(img, mask):
    # Only one candidate is produced in the MVP.
    return [inpaint(img, mask)]
