from typing import Dict, Any, List
import numpy as np
from ..model_manager.manager import MANAGER
def _opencv_inpaint(img, mask_bool):
    import cv2
    data=np.array(img['data'],dtype=np.uint8); mask=(np.array(mask_bool,dtype=np.uint8))*255
    out=cv2.inpaint(data, mask, 3, cv2.INPAINT_TELEA)
    return {'data': out.tolist(), 'meta': {'engine':'opencv_telea'}}
def inpaint(img: Dict[str, Any], mask: List[List[bool]]) -> Dict[str, Any]:
    h=MANAGER.acquire_model('lama')
    if h.obj is not None:
        try:
            # library invocation varies; keep fallback for stability
            pass
        except Exception: pass
    return _opencv_inpaint(img, mask)
