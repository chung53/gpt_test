# 中文注释：唯一写回点（Composer）
# 仅在 text_mask 内对像素进行写入；非 text_mask 区域必须保持 byte-for-byte 不变。
# 这是保证视觉一致性与可审计的关键约束。本MVP在这里执行文本层的覆盖合成。
from typing import Any, Dict, List


def compose(orig: Dict[str, Any], inpainted: Dict[str, Any], text_layer: Dict[str, Any], mask: List[List[bool]]) -> Dict[str, Any]:
    od = orig['data']
    idt = inpainted['data']
    td = text_layer['data']
    h = len(od)
    w = len(od[0]) if h > 0 else 0
    out = [row[:] for row in od]
    for y in range(h):
        for x in range(w):
            if mask[y][x]:
                out[y][x] = td[y][x]
    return {'data': out, 'meta': {'composed': True}}
