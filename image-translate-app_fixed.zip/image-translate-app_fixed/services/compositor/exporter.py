import json
import os
from typing import Dict, Any, List


def export_all(final_img: Dict[str, Any], layout: Dict[str, Any], out_dir: str) -> None:
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, 'final.json'), 'w', encoding='utf-8') as f:
        json.dump(final_img, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, 'layout.json'), 'w', encoding='utf-8') as f:
        json.dump(layout, f, ensure_ascii=False, indent=2)
