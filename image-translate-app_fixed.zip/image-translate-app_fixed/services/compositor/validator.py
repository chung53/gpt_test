# 中文注释：位级校验
# 对比最终图与原图的字节（像素值）是否在非 mask 区域完全一致；如不一致则流程失败。
from typing import Any, Dict, List


def byte_for_byte_same(out: Dict[str, Any], orig: Dict[str, Any], mask: List[List[bool]]) -> bool:
    od = orig['data']
    outd = out['data']
    h = len(od)
    w = len(od[0]) if h > 0 else 0
    for y in range(h):
        for x in range(w):
            if mask[y][x]:
                continue
            if od[y][x] != outd[y][x]:
                return False
    return True
