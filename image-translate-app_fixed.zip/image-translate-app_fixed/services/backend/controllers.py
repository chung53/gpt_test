from .schemas import JobRequest, JobStatus, PreviewResponse
from .db import DB
from ..worker.worker import run_job


def start_job(job_req: JobRequest) -> str:
    job_id = DB.create({'input_path': job_req.input_path, 'params': job_req.params})
    return job_id


def get_status(job_id: str) -> JobStatus:
    record = DB.get(job_id) or {}
    return JobStatus(job_id=job_id, status=record.get('status', 'unknown'), detail=record.get('detail', {}))


def confirm_and_run(job_id: str) -> dict:
    record = DB.get(job_id)
    if not record:
        return {'error': 'job not found'}
    out = run_job(record['payload']['input_path'], record['payload']['params'])
    DB.update(job_id, 'finished', {'outputs': out})
    return out
