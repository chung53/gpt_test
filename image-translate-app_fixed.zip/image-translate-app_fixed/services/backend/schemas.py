try:
    from pydantic import BaseModel
except Exception:
    # Fallback if pydantic isn't installed; provide a minimal BaseModel.
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def dict(self):
            return self.__dict__


class JobRequest(BaseModel):
    input_path: str = ""
    params: dict = {}


class JobStatus(BaseModel):
    job_id: str = ""
    status: str = "pending"
    detail: dict = {}


class PreviewResponse(BaseModel):
    job_id: str = ""
    preview_path: str = ""
    candidates: list = []
