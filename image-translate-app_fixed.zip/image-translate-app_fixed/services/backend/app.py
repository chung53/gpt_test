try:
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse
    from .schemas import JobRequest
    from .controllers import start_job, get_status, confirm_and_run
    app = FastAPI()

    @app.post('/v1/jobs')
    def post_jobs(req: JobRequest):
        job_id = start_job(req)
        return JSONResponse({'job_id': job_id})

    @app.get('/v1/jobs/{jid}/status')
    def status(jid: str):
        st = get_status(jid)
        return JSONResponse(st.dict())

    @app.post('/v1/jobs/{jid}/confirm')
    def confirm(jid: str):
        out = confirm_and_run(jid)
        return JSONResponse(out)
except Exception:
    # When FastAPI is not available, do nothing.  The worker can still be invoked
    # directly from tests or scripts.
    app = None

    if __name__ == '__main__':
        print('FastAPI not available. Backend HTTP server is skipped in MVP.')
