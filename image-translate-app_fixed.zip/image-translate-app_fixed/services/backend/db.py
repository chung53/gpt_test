import time
import uuid


class JobDB:
    """A minimal in-memory store for job metadata."""

    def __init__(self):
        self.store: dict[str, dict] = {}

    def create(self, payload):
        job_id = str(uuid.uuid4())
        self.store[job_id] = {'status': 'created', 'payload': payload, 'ts': time.time()}
        return job_id

    def update(self, job_id: str, status: str, detail: dict | None = None):
        if job_id in self.store:
            self.store[job_id]['status'] = status
            if detail is not None:
                self.store[job_id]['detail'] = detail

    def get(self, job_id: str) -> dict | None:
        return self.store.get(job_id)


DB = JobDB()
