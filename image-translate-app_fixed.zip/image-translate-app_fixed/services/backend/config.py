DB_PATH = ":memory:"
