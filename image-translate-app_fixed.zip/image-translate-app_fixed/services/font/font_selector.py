def select_font(params=None):
    return {'family': 'NotoSans', 'size_px': 16, 'weight': 400, 'stroke': 0, 'shadow': 0}
