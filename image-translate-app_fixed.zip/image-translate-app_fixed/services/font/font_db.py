def search_topk(emb, k: int = 3):
    return ['NotoSans', 'Arial', 'Roboto'][:k]
