def embed(glyph_crop):
    return [0.0, 0.0, 1.0]
