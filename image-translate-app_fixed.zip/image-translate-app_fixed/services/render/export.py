import os


def export_svg(text_layer, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write('<svg><!-- placeholder --></svg>')
