# -*- coding: utf-8 -*-
# 中文注释：
# 本文件实现端到端流水线的“工人（worker）”，串联各个模块：
# 1) OCR -> 2) 分割(SAM占位) -> 3) 修复(LaMa占位) -> 4) 翻译(LLM占位)
# 5) 字体参数选择 -> 6) 渲染文本层 -> 7) 合成 + 位级校验 -> 8) 导出产物
# 该MVP仅使用标准库模拟推理，保留接口与数据契约，便于替换为真实模型。
import os
import time
from typing import Any, Dict

from ..ocr.ocr_service import run_ensemble
from ..segmentation.sam_wrapper import generate_mask
from ..segmentation.refine import refine
from ..inpainting.candidate_manager import generate_and_rank
from ..translation.translator import translate_units
from ..font.font_selector import select_font
from ..render.renderer import render_text_on_bg
from ..compositor.composer import compose
from ..compositor.validator import byte_for_byte_same
from ..compositor.exporter import export_all
from tools.utils.image_io import load_image, save_image
from .task_defs import default_params


def run_job(input_path: str, params: Dict[str, Any] | None = None) -> Dict[str, Any]:
    params = params or default_params()
    img = load_image(input_path)

    # OCR
    units = run_ensemble(img, params.get('ocr', {}))

    # Segmentation
    mask = generate_mask(img, units[0]['bbox'])
    mask, mask_meta = refine(mask)

    # Inpainting candidates
    candidates = generate_and_rank(img, mask)
    inpainted = candidates[0]

    # Translation
    tr_units = translate_units(units, params.get('translation', {}))

    # Font selection
    font_params = select_font()

    # Render text layer
    text_layer = render_text_on_bg(img, tr_units, font_params)

    # Compose
    final_img = compose(img, inpainted, text_layer, mask)

    # Validate non-mask bytes unchanged
    assert byte_for_byte_same(final_img, img, mask), "Non-mask region changed!"

    # Export
    out_dir = os.path.abspath(os.path.join(os.path.dirname(input_path), '..', 'outputs', f'job_{int(time.time())}'))
    layout = {
        'units': units,
        'translated_units': tr_units,
        'mask_meta': mask_meta,
        'font_params': font_params,
    }
    export_all(final_img, layout, out_dir)
    return {
        'out_dir': out_dir,
        'final': os.path.join(out_dir, 'final.json'),
        'layout': os.path.join(out_dir, 'layout.json'),
    }
