from typing import Dict, Any


def default_params() -> Dict[str, Any]:
    return {
        'ocr': {'force_text': 'Hello'},
        'translation': {'style': 'literal'},
    }
