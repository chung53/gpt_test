from typing import Dict, Any, List, Tuple
import numpy as np
from .mask_utils import rect_mask
from ..model_manager.manager import MANAGER
def _bbox_to_points(b): x1,y1,x2,y2=b; return (np.array([[(x1+x2)//2, (y1+y2)//2]],dtype=np.float32), np.array([1],dtype=np.int32))
def generate_mask(img: Dict[str, Any], bbox) -> List[List[bool]]:
    h=len(img['data']); w=len(img['data'][0]) if h>0 else 0
    hdl = MANAGER.acquire_model('sam')
    if hdl.obj is not None:
        try:
            pred = hdl.obj
            np_img=np.array(img['data'],dtype=np.uint8); np_img=np.stack([np_img]*3,axis=-1)
            pred.set_image(np_img); pts,labels=_bbox_to_points(bbox)
            masks,scores,_=pred.predict(point_coords=pts, point_labels=labels, multimask_output=True)
            return masks[int(scores.argmax())].astype(bool).tolist()
        except Exception: pass
    return rect_mask(h,w,bbox)
