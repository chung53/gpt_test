from typing import List


def rect_mask(h: int, w: int, bbox) -> List[List[bool]]:
    x1, y1, x2, y2 = bbox
    m = [[False] * w for _ in range(h)]
    for y in range(max(0, y1), min(h, y2)):
        for x in range(max(0, x1), min(w, x2)):
            m[y][x] = True
    return m
