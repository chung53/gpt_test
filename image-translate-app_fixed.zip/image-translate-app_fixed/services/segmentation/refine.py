# The refine function returns the mask unmodified along with metadata.
def refine(mask):
    return mask, {'mask_confidence': 0.85}
