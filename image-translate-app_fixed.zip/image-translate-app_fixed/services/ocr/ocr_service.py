# 中文注释：OCR占位实现
# 并不依赖真实OCR引擎，仅生成一个示例文本单元（central bbox）。
# 输出统一结构：id/src_text/bbox/orientation/block_type/confidence
from typing import Any, Dict, List


def run_ensemble(img: Dict[str, Any], params: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return a single OCR text unit covering the centre region."""
    h = len(img['data'])
    w = len(img['data'][0]) if h > 0 else 0
    text = params.get('force_text', 'Hello')
    bbox = [w // 4, h // 4, w * 3 // 4, h * 3 // 4]  # [x1, y1, x2, y2]
    return [{
        'id': 't1',
        'src_text': text,
        'bbox': bbox,
        'orientation': 0,
        'block_type': 'body',
        'confidence': 0.9,
    }]
