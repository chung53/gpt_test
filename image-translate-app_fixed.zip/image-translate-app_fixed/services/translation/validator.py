def back_translation_check(text: str) -> float:
    # Always return a constant confidence in the MVP.
    return 0.9
