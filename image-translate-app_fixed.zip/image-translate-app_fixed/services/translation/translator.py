# 中文注释：翻译（LLM占位）
# 以段落/文本单元为粒度，调用 LLM 客户端进行翻译；
# MVP 中直接回传示例译文字符串与置信度。
from typing import Any, Dict
from .llm_client import CLIENT


def translate_units(units, params: Dict[str, Any]):
    out = []
    style = params.get('style', 'literal')
    for u in units:
        tgt = CLIENT.translate(u['src_text'], style=style)
        out.append({'id': u['id'], 'tgt_text': tgt, 'conf': 0.95})
    return out
