class LLMClient:
    def __init__(self):
        self._pipe=None
        try:
            from ..model_manager.manager import MANAGER
            self._pipe=MANAGER.acquire_model('llm_translation').obj
        except Exception: self._pipe=None
    def translate(self, text: str, style: str='literal', src_lang: str='zho_Hans', tgt_lang: str='eng_Latn'):
        if self._pipe is not None:
            try:
                tok=getattr(self._pipe,'tokenizer',None)
                if tok is not None and hasattr(tok,'lang_code_to_id'):
                    self._pipe.tokenizer.src_lang=src_lang
                    return self._pipe(text, forced_bos_token_id=tok.lang_code_to_id[tgt_lang])[0]['translation_text']
                return self._pipe(text)[0]['translation_text']
            except Exception: pass
        return f"{text} (translated:{style})"
    def back_translate(self, text: str, src_lang: str='eng_Latn', tgt_lang: str='zho_Hans'):
        try: return self.translate(text, src_lang=src_lang, tgt_lang=tgt_lang)
        except Exception: return text
CLIENT=LLMClient()
