import os, time
class ModelHandle:
    def __init__(self, name, obj=None, meta=None):
        self.name=name; self.obj=obj; self.meta=meta or {}; self.created=time.time()
class ModelManager:
    _inst=None
    def __new__(cls): 
        if not cls._inst: cls._inst=super().__new__(cls)
        return cls._inst
    def __init__(self): self._cache={}
    def acquire_model(self, name, mode='default'):
        if name in self._cache: return self._cache[name]
        loader = getattr(self, f"_load_{name}", None)
        h = loader(mode) if loader else ModelHandle(name, None, {'fallback':'none'})
        self._cache[name]=h; return h
    def release_model(self, h): return True
    def _load_llm_translation(self, mode='default'):
        try:
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, pipeline
            hub_id = os.environ.get('LLM_TRANSLATION_ID','facebook/nllb-200-3.3B')
            tok = AutoTokenizer.from_pretrained(hub_id)
            mdl = AutoModelForSeq2SeqLM.from_pretrained(hub_id, device_map='auto', torch_dtype='auto')
            pipe = pipeline('translation', model=mdl, tokenizer=tok, device_map='auto')
            return ModelHandle('llm_translation', pipe, {'hub_id':hub_id})
        except Exception as e:
            return ModelHandle('llm_translation', None, {'error':repr(e),'fallback':'simple'})
    def _load_sam(self, mode='default'):
        try:
            import torch
            from segment_anything import sam_model_registry, SamPredictor
            ckpt = os.environ.get('SAM_CKPT','/models/sam_vit_h_4b8939.pth')
            sam = sam_model_registry['vit_h'](checkpoint=ckpt)
            sam.to('cuda' if torch.cuda.is_available() else 'cpu')
            return ModelHandle('sam', SamPredictor(sam), {'ckpt':ckpt})
        except Exception as e:
            return ModelHandle('sam', None, {'error':repr(e),'fallback':'rect_mask'})
    def _load_lama(self, mode='default'):
        try:
            import lama_cleaner
            return ModelHandle('lama', lama_cleaner, {'engine':'lama-cleaner'})
        except Exception as e:
            return ModelHandle('lama', None, {'error':repr(e),'fallback':'opencv_inpaint'})
MANAGER = ModelManager()
