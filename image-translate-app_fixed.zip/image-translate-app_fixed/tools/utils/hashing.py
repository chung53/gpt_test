import hashlib
import json


def hash_obj(obj) -> str:
    """Compute a SHA256 hash of a JSON‑serialisable object."""
    s = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(s.encode('utf-8')).hexdigest()
