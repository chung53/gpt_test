from typing import List


def l2(a: List[List[int]], b: List[List[int]], mask=None) -> int:
    """Compute a simple L2 difference for non-mask regions."""
    h = min(len(a), len(b))
    w = min(len(a[0]), len(b[0])) if h > 0 else 0
    s = 0
    for i in range(h):
        for j in range(w):
            if mask is not None and mask[i][j]:
                continue
            s += (a[i][j] - b[i][j]) ** 2
    return s
