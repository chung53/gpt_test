import json
import os
from typing import Any, Dict, List


def load_image(path: str) -> Dict[str, Any]:
    """Load a toy image represented as a JSON file."""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_image(img: Dict[str, Any], path: str) -> None:
    """Save a toy image to a JSON file."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(img, f, ensure_ascii=False, indent=2)


def shape(img: Dict[str, Any]) -> tuple[int, int]:
    """Return (height, width) of the image data."""
    data = img['data']
    return len(data), len(data[0]) if data else 0
